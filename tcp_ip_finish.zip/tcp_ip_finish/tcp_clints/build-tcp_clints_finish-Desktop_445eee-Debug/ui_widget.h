/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created by: Qt User Interface Compiler version 5.9.5
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QLineEdit *leipAddress;
    QLineEdit *leport;
    QPushButton *connectBtn;
    QTextBrowser *textReceive;
    QListWidget *listWidget;
    QPlainTextEdit *textSend;
    QPushButton *sendBtn;
    QLabel *label_2;
    QLabel *label;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName(QStringLiteral("Widget"));
        Widget->resize(601, 424);
        leipAddress = new QLineEdit(Widget);
        leipAddress->setObjectName(QStringLiteral("leipAddress"));
        leipAddress->setGeometry(QRect(100, 20, 151, 21));
        leport = new QLineEdit(Widget);
        leport->setObjectName(QStringLiteral("leport"));
        leport->setGeometry(QRect(350, 20, 81, 21));
        connectBtn = new QPushButton(Widget);
        connectBtn->setObjectName(QStringLiteral("connectBtn"));
        connectBtn->setGeometry(QRect(480, 20, 81, 28));
        textReceive = new QTextBrowser(Widget);
        textReceive->setObjectName(QStringLiteral("textReceive"));
        textReceive->setGeometry(QRect(20, 60, 381, 301));
        listWidget = new QListWidget(Widget);
        listWidget->setObjectName(QStringLiteral("listWidget"));
        listWidget->setGeometry(QRect(420, 60, 171, 341));
        textSend = new QPlainTextEdit(Widget);
        textSend->setObjectName(QStringLiteral("textSend"));
        textSend->setGeometry(QRect(20, 380, 291, 31));
        sendBtn = new QPushButton(Widget);
        sendBtn->setObjectName(QStringLiteral("sendBtn"));
        sendBtn->setGeometry(QRect(320, 380, 81, 28));
        label_2 = new QLabel(Widget);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(20, 20, 72, 15));
        label = new QLabel(Widget);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(280, 20, 72, 15));

        retranslateUi(Widget);

        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QApplication::translate("Widget", "Client", Q_NULLPTR));
        leipAddress->setText(QApplication::translate("Widget", "127.0.01", Q_NULLPTR));
        leport->setText(QApplication::translate("Widget", "8888", Q_NULLPTR));
        connectBtn->setText(QApplication::translate("Widget", "connect", Q_NULLPTR));
        sendBtn->setText(QApplication::translate("Widget", "send", Q_NULLPTR));
        label_2->setText(QApplication::translate("Widget", "ip address", Q_NULLPTR));
        label->setText(QApplication::translate("Widget", "port", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
