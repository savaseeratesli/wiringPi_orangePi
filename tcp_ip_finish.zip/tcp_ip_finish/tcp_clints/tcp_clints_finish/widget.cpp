#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    ui->connectBtn->setStyleSheet("background-color: rgb(6,163,220)");
    ui->sendBtn->setStyleSheet("background-color: rgb(6,163,220)");
    ui->leport->setStyleSheet("color:blue");
    ui->leipAddress->setStyleSheet("color:blue");

    ui->listWidget->setStyleSheet("border:2px solid blue");

    socket = new QTcpSocket(this);
    connectState = false;     //bağlı değil

    //messageSound = new QSound(":/new/prefix1/sounds/iphone.wav", this);
    //connectSound = new QSound(":/new/prefix1/sounds/keke.wav", this);

    this->setWindowIcon(QIcon(":/new/prefix1/image/qq.png"));

    connect(socket, &QTcpSocket::readyRead, this, &Widget::readMessage);
    connect(socket, &QTcpSocket::disconnected, this, &Widget::disconnectSlot);   //bağlantı kesme bilgilerini yazdır

    wiringPiSetup();
    pinMode(0,OUTPUT);
    pinMode(1,OUTPUT);
}

Widget::~Widget()
{
    delete ui;
}


void Widget::readMessage()
{

    messageSound->play();
    QByteArray arr = socket->readAll();
    QString str;
    str =  arr.data();
    ui->textReceive->append(str);     //mektubu göster

    //Wiring Pi ile pin High-Low

    if(str=="1"){
        digitalWrite(0,HIGH);
        digitalWrite(1,LOW);
    }
    else if(str=="2"){
         digitalWrite(0,LOW);
         digitalWrite(1,HIGH);
    }


}


void Widget::disconnectSlot()    //bağlantı kesme bilgilerini yazdır
{
    ui->listWidget->addItem("bağlantı kesildi");
}


void Widget::on_connectBtn_clicked()      //İstemciye bağlanın veya bağlantıyı kesin
{
    QString ipStr = ui->leipAddress->text();    //Arayüzde görüntülenen adres
    quint16 currentPort = ui->leport->text().toInt();   //Arayüzde görüntülenen geçerli bağlantı noktası
    if(!connectState)    //İstemci henüz sunucuya bağlanmadı
    {
        socket->connectToHost(ipStr, currentPort);   //sunucuya bağlan
        if(socket->waitForConnected())   //Bağlantının başarılı olmasını bekleyin
        {
            ui->listWidget->addItem("bağlantı başarılı");
            ui->connectBtn->setText("bağlantıyı kapat");
            connectSound->play();
            connectState = true;
        }

        else     //Bağlantı başarısız
        {
            QMessageBox::warning(this, "Bağlantı başarısız", socket->errorString());   //Bağlantı hatası mesajı hatırlatıcısı
        }
    }

    else   //istemci bağlı
    {
        socket->close();   //Soketi kapatın, bağlantısı kesilmiş sinyal şu ​​anda gönderilecek
        connectSound->play();
        ui->connectBtn->setText("Bağlan");
    }
}


void Widget::on_sendBtn_clicked()    //Sunucuya bilgi gönder
{
    QString str = ui->textSend->toPlainText();
    if(socket->isOpen() && socket->isValid())
    {
        socket->write(str.toUtf8());    //Sunucuya bilgi gönder
        ui->textSend->clear();
    }

    QString showStr = QDateTime::currentDateTime().toString("dddd yyyy.MM.dd hh:mm:ss") + '\n' + str;
    ui->textReceive->append(showStr);     //Kendiniz tarafından gönderilen mesajları göster
}








