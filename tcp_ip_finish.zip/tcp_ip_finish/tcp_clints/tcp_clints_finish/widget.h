#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QTcpSocket>
#include <QString>
#include <QByteArray>
#include <QDateTime>
#include <QMessageBox>
#include <QSound>
#include <QIcon>
#include "wiringPi.h"
#include "crypt.h"
#include <crypt.h>


namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = nullptr);
    ~Widget();

    QSound *messageSound;
    QSound *connectSound;
private slots:
    void on_connectBtn_clicked();   //bağlantı düğmesi

    void on_sendBtn_clicked();      //gönderme butonu

    void readMessage();

    void disconnectSlot();          //yuva işlevini kes

    void on_leipAddress_cursorPositionChanged(int arg1, int arg2);

private:
    Ui::Widget *ui;
    QTcpSocket *socket;
    bool connectState;  //İstemci bağlantı durumu

};

#endif // WIDGET_H
