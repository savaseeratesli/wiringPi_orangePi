#include "widget.h"
#include "ui_widget.h"
#include <fstream>


#include <QWidget>


Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    ui->listenBtn->setStyleSheet("background-color: rgb(6,163,220)");


    ui->sendBtn->setStyleSheet("background-color: rgb(6,163,220)");


    ui->leport->setStyleSheet("color:blue");

    ui->ipBox->setStyleSheet("color:blue");
    ui->ipBox->setStyleSheet("background-color: rgb(6,163,220)");


    ui->textSend->setStyleSheet("border:red");


    ui->label_2->setStyleSheet("color:blue");
    ui->label_3->setStyleSheet("color:blue");
    ui->listWidget->setStyleSheet("border:2px solid blue");     //kenarlık rengini değiştir
    //ui->textReceive->setStyleSheet("border:2px groove gray;border-radius:10px;padding:2px 4px");
    //this->setStyleSheet("QWidget{border-top-left-radius:15px;border-top-right-radius:5px;}");

    this->setWindowIcon(QIcon(":/new/prefix1/images/qq.png"));

    //connectSound = new QSound(":/new/prefix1/sounds/keke.wav", this);
    //messSound = new QSound(":/new/prefix1/sounds/iphone.wav", this);
    severe = new QTcpServer(this);      //sunucu oluştur
    this->enumAllIp();   //ip adresini başlat
    connect(severe, &QTcpServer::newConnection, this, &Widget::newConnectSlot);     //Yeni bir bağlantı olduğunda gelen sinyal
}

Widget::~Widget()
{
    delete ui;
}

void Widget::enumAllIp()    //Makinedeki tüm kullanılabilir ipv4 adreslerini sıfırlayın ve adresleri liste kutusuna ekleyin
{
    QList <QHostAddress> addressList = QNetworkInterface::allAddresses();     //Makinenin tüm IP adreslerini alın
    QStringList addressList_str;
    for(int i = 0; i < addressList.size(); i++)
    {
        if(addressList.at(i).isNull()) continue;   //Adres boşsa atla
        if(addressList.at(i).protocol() != QAbstractSocket::IPv4Protocol) continue;   //Protokol ailesi ipv4 değilse atla
        addressList_str.append(addressList.at(i).toString());      //Uygun adresler listeye eklenir
    }

    ui->ipBox->addItems(addressList_str);   //Adres listesini adres listesi kutusuna ekleyin
}

void Widget::newConnectSlot()    //yeni istemci bağlantısı
{
    connectSound->play();
    clintSock = severe->nextPendingConnection();      //Şu anda bağlı olan istemci soketini alın
    clintList_sock.push_back(clintSock);           //Bağlı istemcileri istemci listesine yerleştirin
    QString str= clintSock->peerAddress().toString() + ":" + QString::number(clintSock->peerPort()) + "bağlandı";
    ui->listWidget->addItem(str);  //Bağlantı bilgilerini liste penceresine koy

    connect(clintSock, &QTcpSocket::readyRead, this, &Widget::readMessage);  //bilgi almaya hazır
    connect(clintSock, &QTcpSocket::disconnected, this, &Widget::disConnectSlot);   //İstemci bağlantı kesme bilgileri

}

void Widget::readMessage()      //Müşteri bilgilerini okuyun ve diğer müşterilere bilgi gönderin
{
    QTcpSocket*  currentClint;
    QByteArray arr;
    QString str;
    if(!clintList_sock.isEmpty())      //müşteri var
    {
        for(int i = 0; i < clintList_sock.count(); i++)     //Sunucu bilgi alır
        {
            arr = clintList_sock.at(i)->readAll();      //İstemci tarafından gönderilen bayt bilgilerini alın
            if(arr.isNull())  continue;   //Boş, müşteri tarafından gönderilmediği anlamına gelir
            messSound->play();
            currentClint = clintList_sock.at(i);
            str = QDateTime::currentDateTime().toString("dddd.yyyy.MM.dd HH:mm:ss") + '\n' + arr.data();
            break;
        }

        ui->textReceive->append(str);     //Bilgileri görüntüle

        for(int i = 0; i < clintList_sock.count(); i++)     //Diğer müşterilere bilgi gönderin
        {
            QTcpSocket *temp = clintList_sock.at(i);
            if(currentClint == temp)  continue;      //Kendinle tanıştığında atla
            temp->write(str.toUtf8());   //mesaj gönder
        }
    }

}


void Widget::disConnectSlot()       //İstemci bağlantısı kesildiğinde, sunucu bir bağlantı kesme mesajı görüntüler.
{
    connectSound->play();
    QString closeStr = QDateTime::currentDateTime().toString("dddd.yyyy.MM.dd HH:mm:ss") + ' ' + "Kapattı";
    ui->listWidget->addItem(closeStr);
}



void Widget::on_listenBtn_clicked()      //Sunucu dinlemeye başlar
{
    QString currentIp = ui->ipBox->currentText();     //Geçerli ip listesinin IP'si
    quint16 currentPort = ui->leport->text().toInt();       //Geçerli metin kutusunun görüntülenen bağlantı noktası
    QHostAddress currentHostIP = QHostAddress(currentIp);   //Adres dizesini ana bilgisayar IP'sine dönüştürün
    if(severe->isListening())     //müşteri dinliyor

    {
        severe->close();   //istemciyi kapat
        ui->listenBtn->setText("start");
    }

    else    //Müşteri dinlemiyor
    {
        if(severe->listen(currentHostIP, currentPort))   //Dinleyici başarısı true değerini döndürür
        {
            ui->listenBtn->setText("stop server");
        }

        else    //İzleme başarısız oldu
            QMessageBox::warning(this, "listen error", severe->errorString());   //Bir hata mesajı kutusu belirir
    }
}

void Widget::on_sendBtn_clicked()     //Müşteriye bilgi gönder
{
    QString sendStr = ui->textSend->toPlainText();
     for(int i = 0; i < clintList_sock.count(); i++)
     {
         clintList_sock.at(i)->write(sendStr.toUtf8());
         ui->textSend->clear();
     }

     //QString showStr = QDateTime::currentDateTime().toString("dddd.yyyy.MM.dd HH:mm:ss") + '\n' + sendStr;
     // ui->textReceive->append(showStr);
     //ui->textSend->clear();
}


void Widget::on_pushButton_clicked()
{
    QFile file("/home/orangepi/Desktop/projects/Qt_tcp_chatroom-master/tcp_ip_finish/tcp_severe/build-select_clients-Desktop_445eee-Debug/clients.txt");

    QString line = ui->textSend->toPlainText();

   if (file.open(QIODevice::ReadOnly | QIODevice::Text)){
       QTextStream stream(&file);
       while (!stream.atEnd()){


           line.append(stream.readLine()+"\n");
                ui->textSend->setPlainText(line);
       }
       file.close();
}
}

