#ifndef WIDGET_H
#define WIDGET_H


#include <QWidget>
#include <QTcpServer>
#include <QTcpSocket>
#include <QString>
#include <QByteArray>
#include <QList>
#include <QAbstractSocket>
#include <QMessageBox>
#include <QStringList>
#include <QDateTime>
#include <QNetworkInterface>
#include <QMediaPlayer>
#include <QSound>
#include <QIcon>
#include <fstream>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QGroupBox>
#include <QMessageBox>
#include <QListView>
#include <QDialogButtonBox>

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:

    explicit Widget(QWidget *parent = nullptr);
    ~Widget();
    QMediaPlayer *startSound;  //Bir müzik çalar oluşturun
    QSound *connectSound;
    QSound *messSound;


    void enumAllIp();         //Kullanılabilir tüm ipv4 adreslerini makinede saklayın
private slots:

    void newConnectSlot();      //İstemci bağlantısı sonrası işleme
    void disConnectSlot();      //İstemci bağlantısı kesildikten sonra işleniyor
    void readMessage();         //Bilgi almak için yuva işlevi



    void on_listenBtn_clicked();      //Dinleyici yuvası işlevi

    void on_sendBtn_clicked();       //Mesaj yuvası işlevi gönder






    void on_pushButton_clicked();

private:
    Ui::Widget *ui;
    QTcpServer *severe;   //sunucu
    QList <QTcpSocket*> clintList_sock;   //Birden çok istemci için soket listesi
    QTcpSocket *clintSock;



    QGroupBox* viewBox;
    QPushButton* saveButton;
    QPushButton* closeButton;


};


#endif // WIDGET_H
